BUBBLEBOX PAYMENTS UPDATE — Deploy Guide
=========================================

FRONTEND (deploy now)
---------------------
Everything in frontend-changes/ goes into the bubblebox-app repo on GitHub,
keeping the same folder paths. On your phone: github.com -> bubblebox-app ->
Add file -> Upload files. Vercel auto-deploys.

  app/pay/[id]/page.tsx          NEW  - customer payment page (bubbleboxatl.com/pay/{id})
  app/admin/payments/page.tsx    NEW  - admin Payments tab with Capture / Refund
  app/admin/layout.tsx           EDIT - adds Payments to the sidebar
  app/admin/bookings/page.tsx    EDIT - debounced search (was 1 API call per keystroke)
  app/book/page.tsx              EDIT - removed Stripe debug logs from checkout
  lib/admin-api.ts               EDIT - adds capturePayment / refundPayment
  public/logo.png                EDIT - 957KB -> 73KB
  public/icons/icon-192.png      EDIT - 957KB -> 33KB (this loads on EVERY page)

NOTE: GitHub's web uploader can't create the [id] folder name directly.
If the upload rejects it, use "Add file -> Create new file" instead and type
the path  app/pay/[id]/page.tsx  in the filename box, then paste the contents.

BACKEND (when you have server access)
-------------------------------------
backend-changes/payments-admin-routes.js — drop into Bubblebox2.0 and wire:

  const registerPayments = require("./payments-admin-routes");
  const { sendPayNowSms } = registerPayments({
    router: app, pool, stripe, requireAdmin, sendSms,
  });

Then in your POST /api/bookings handler, after the booking is created:

  if (booking.payment_status === "pending") {
    sendPayNowSms(booking).catch(console.error);
  }

Also while you're on the server:
  1. Add compression: Caddyfile "encode gzip" (or app.use(compression()))
  2. Cache /api/services: res.set("Cache-Control","public, max-age=300")
  3. Push Bubblebox2.0 to GitHub so it can't be lost again
  4. Delete test booking bk_rL9S6hGDFwrv from the admin panel
  5. Switch Stripe to live keys before launch
